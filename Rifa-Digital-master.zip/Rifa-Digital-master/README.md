# Rifa Digital


## O que o projeto faz:
Basicamente você pode comprar rifas e vender rifas na web desprezando o uso do papel.

## Recursos


### Rifador
    - Colocar imagem da Rifa
    - Escolher quantidades de numeros, data de sorteio e valor
### Comprador
    - Comprar a rifa por meios facil de pagamento como exemplo cartão de credito
    - Acompanhar rifas compradas no painel do usúario

## Recursos Futuros
    - Fazer automaticos os sorteios das rifas do dia [ ]
    - Exibir rifas que foram sorteadas e o numero sorteado [ ]





This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `yarn start`

Runs the app in the development mode.<br />
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.<br />
You will also see any lint errors in the console.
